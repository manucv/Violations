/* Thai translation for the jQuery Timepicker Addon */
/* Written by Yote Wachirapornpongsa */
(function($) {
	$.timepicker.regional['th'] = {
		timeOnlyTitle: 'เลือกเวลา',
		timeText: 'เวลา ',
		hourText: 'ชั่วโมง ',
		minuteText: 'นาที',
		secondText: 'วินาที',
		millisecText: 'มิลลิวินาที',
		microsecText: 'ไมโคริวินาที',
		timezoneText: 'เขตเวลา',
		currentText: 'เวลาปัจจุบัน',
		closeText: 'ปิด',
		timeFormat: 'hh:mm tt'
	};
	$.timepicker.setDefaults($.timepicker.regional['th']);
})(jQuery);